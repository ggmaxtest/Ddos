import requests
import concurrent.futures
import os
import time

# ── Configurações ──────────────────────────────────────────
INPUT_FILE   = "proxies.txt"   # arquivo com os proxies
OUTPUT_DIR   = "proxies_validos"
OUTPUT_FILE  = os.path.join(OUTPUT_DIR, "validos.txt")
TEST_URL     = "http://httpbin.org/ip"  # URL usada para testar
TIMEOUT      = 5        # segundos por proxy
MAX_WORKERS  = 100      # threads simultâneas (aumente se tiver CPU boa)
# ──────────────────────────────────────────────────────────

os.makedirs(OUTPUT_DIR, exist_ok=True)

def load_proxies(path):
    with open(path, "r") as f:
        return [line.strip() for line in f if line.strip()]

def test_proxy(proxy):
    proxies = {
        "http":  f"http://{proxy}",
        "https": f"http://{proxy}",
    }
    try:
        r = requests.get(TEST_URL, proxies=proxies, timeout=TIMEOUT)
        if r.status_code == 200:
            return proxy, True
    except Exception:
        pass
    return proxy, False

def main():
    proxies = load_proxies(INPUT_FILE)
    total   = len(proxies)
    print(f"🔍 Testando {total} proxies com {MAX_WORKERS} threads...\n")

    validos = []
    start   = time.time()

    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(test_proxy, p): p for p in proxies}
        done    = 0

        for future in concurrent.futures.as_completed(futures):
            proxy, ok = future.result()
            done += 1

            if ok:
                validos.append(proxy)
                print(f"  ✅  {proxy}")

            # progresso a cada 100
            if done % 100 == 0 or done == total:
                pct = done / total * 100
                print(f"  [{done}/{total}] {pct:.1f}%  —  {len(validos)} válidos até agora")

    elapsed = time.time() - start

    with open(OUTPUT_FILE, "w") as f:
        f.write("\n".join(validos))

    print(f"\n{'─'*50}")
    print(f"✅  Válidos : {len(validos)}")
    print(f"❌  Inválidos: {total - len(validos)}")
    print(f"⏱️  Tempo    : {elapsed:.1f}s")
    print(f"📄  Salvos em: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
